import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-image',
  templateUrl: './show-image.component.html',
  styleUrls: ['./show-image.component.scss']
})
export class ShowImageComponent implements OnInit {

  constructor(private httpClient: HttpClient, private router:Router) { }
  imageName: any;
  
  retrievedImage: any;
  base64Data: any;
  retrieveResonse: any;
  message: string;
  //imgName:String;
  ngOnInit() {
    this.imageName=localStorage.getItem("selectedImage")
    console.log(this.imageName)
    this.getImage();
  }
 //Gets called when the user clicks on retieve image button to get the image from back end
 getImage() {
  //Make a call to Sprinf Boot to get the Image Bytes.
  this.httpClient.get('http://localhost:8080/image/get/' + this.imageName)
    .subscribe(
      res => {
        this.retrieveResonse = res;
        this.base64Data = this.retrieveResonse.picByte;
        this.retrievedImage = 'data:image/jpeg;base64,' + this.base64Data;
      }
    );
}

}
