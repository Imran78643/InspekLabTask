import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UploadedImageListComponent } from './uploaded-image-list/uploaded-image-list.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { LoaderInterceptor } from './loader-interceptor.service';
import { LoaderService } from './loader.service';
import { ShowImageComponent } from './show-image/show-image.component';
import { UploadImageComponent } from './upload-image/upload-image.component';
import { NgxImageZoomModule } from 'ngx-image-zoom';
@NgModule({
  declarations: [
    AppComponent,
    UploadedImageListComponent,
    ShowImageComponent,
    UploadImageComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    NgxImageZoomModule
  ],
  providers: [ LoaderService,{ provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true },],
  bootstrap: [AppComponent]
})
export class AppModule { }
