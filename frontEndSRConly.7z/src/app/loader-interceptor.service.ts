import { Injectable } from "@angular/core";
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse, HttpErrorResponse } from "@angular/common/http";
import { catchError, retry, tap } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
//import { CookieService } from 'ngx-cookie-service';
import { finalize } from "rxjs/operators";
import { LoaderService } from './loader.service';
//import { AlertService } from "src/app/alertService";
import { Router } from "@angular/router";
//import { AuthService } from "src/app/auth/auth.service";

@Injectable()
export class LoaderInterceptor implements HttpInterceptor {
    constructor(public loaderService: LoaderService, 
                private router: Router, 
                
               // private authService:AuthService,
                // private cookieService: CookieService,
                //private alertService: AlertService
                ) { }
    
   token: any = ""
    intercept(req: HttpRequest<any>, next: HttpHandler): any {
        console.log(req);
        // this.cookieService.set('DummyCookie', "Dummmy")
        // console.log(this.cookieService.get('JSESSIONID'))
        // this.loaderService.show();
        
        this.token=localStorage.getItem("token")
        
        let tokenToSend:any=""
      
        if(sessionStorage.getItem("token")){
            tokenToSend='Bearer '+sessionStorage.getItem("token")
        }
        
       
          
           
                req = req.clone({
                    // withCredentials: true,
                    setHeaders: {
                      Authorization: tokenToSend,
                     
                    }
                  });
          


                 
        

        return next.handle(req).pipe(
            // retry(1),
           
            tap((event: HttpEvent<any>) => {
               
           
                if (event instanceof HttpResponse) {
                   
                    console.log(event);
                //     let headers;
                //     const keys = req.headers.keys();
                //   headers = keys.map(key =>
                //       `${key}: ${req.headers.get(key)}`);

                //      console.log(headers) 
                    // var request= new XMLHttpRequest();
                    // request.open(req.method,req.url, false);
                    // request.send(null)
                    // var headers = request.getAllResponseHeaders();
                    
                    // let arr = headers.split("\n");
                    // for(let item of arr){
                    
                    //     if(item.includes("smtoken")){

                    //     this.token=(item.split(":")[1]);
                    //     localStorage.setItem("token",this.token);
                    //     break
                    //     }
                    // };
                    

                };
                
            }),

            catchError((error: HttpErrorResponse) => {
               
             
                let errMsg = '';
                // Client Side Error

                if (error.error instanceof ErrorEvent) {
                    errMsg = `Error: ${error.error.message}`;
                  //  this.alertService.show(errMsg);
                   
                }
                else {
                    // console.log("error me hain")
                    // Server Side Error
                    errMsg = `Error Code: ${error.status},  Message: ${error.message}`;
                    if (error.status == 500 || error.status == 0 || error.status == 404) {
                        errMsg = "Error Code:" + error.status + ", Message: Unable to Connect!";

                        
                    }
                    if (error.status == 200){
                        console.log(error.message)
                        if((error.message).includes("error.jsp")){
                          //  this.alertService.show("Session has expired, please log in again!");
                            let loggedOut:boolean=false
                            
                            this.router.navigate([""]);
                            
                            localStorage.clear();
                           
                            

                        }
                    } 
                    else {
                      //  this.alertService.show(errMsg);
                    }

                }

               
                return throwError(errMsg);
            }),
            finalize(() => {
              //  this.loaderService.hide();
                console.log(req);
                //   if(req.body.token){
                //       console.log(req.body.token)
                //       localStorage.setItem("sessionId",req.body.token)
                //     // this.router.navigate(['/ipCheck']);
                //   }
            })
        );
    }
}
