import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
@Injectable()
export class LoaderService {
    alertMessage:string=""
    showLoader:boolean 
    
    show() {
       
        this.showLoader = true
    }
    hide() {
       
        this.showLoader = false
    }
}