import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-uploaded-image-list',
  templateUrl: './uploaded-image-list.component.html',
  styleUrls: ['./uploaded-image-list.component.scss']
})
export class UploadedImageListComponent implements OnInit {

  constructor(private httpClient: HttpClient, private router:Router) { }
  imageName: any;
  
  retrievedImage: any;
  base64Data: any;
  retrieveResonse: any;
  message: string;
   imageList:any=[];
  ngOnInit() {
    this.getImageList();
  }
 //Gets called when the user clicks on retieve image button to get the image from back end
 getImageList() {
  //Make a call to Sprinf Boot to get the Image Bytes.
  
  this.httpClient.get('http://localhost:8080/getImageList')
    .subscribe(
      res => {
       this.imageList=res;
       console.log(this.imageList);
      }
    );
}
fetchImage(imgName){
  console.log(imgName);
  localStorage.setItem("selectedImage",imgName)
  this.router.navigate(['/showImage']);
}

}
