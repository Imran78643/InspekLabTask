import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { ShowImageComponent } from './show-image/show-image.component';
import { UploadImageComponent } from './upload-image/upload-image.component';
import { UploadedImageListComponent } from './uploaded-image-list/uploaded-image-list.component';

const routes: Routes = [
  { path: '', redirectTo: '/uploadImage', pathMatch: 'full' },
  {path:'uploadImage',component:UploadImageComponent},
  { path: 'showList', component: UploadedImageListComponent },
  { path: 'showImage', component: ShowImageComponent },
  { path: '**', component: UploadImageComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
