import { HttpClient } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ApicallsService } from './apicalls.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor(private http:HttpClient){

  }
  ngOnInit(){
    //sessionStorage.clear();

    let harcodedUsernamePassword={"username":"inspektLabs", "password":"inspektLabs"};
    this.http.post<any>("http://localhost:8080/authenticate",harcodedUsernamePassword).subscribe(data=>{console.log(data);
    sessionStorage.setItem("token",data.token)});
  }
  
}
//ngx-image-zoom for image zoom
//angular maaterial
//