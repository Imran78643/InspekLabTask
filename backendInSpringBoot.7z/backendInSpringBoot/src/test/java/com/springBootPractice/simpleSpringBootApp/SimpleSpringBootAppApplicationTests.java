package com.springBootPractice.simpleSpringBootApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleSpringBootAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
