//package com.backendTest.simpleSpringBootApp;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.h2.H2ConsoleProperties;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.core.annotation.Order;
//import org.springframework.http.HttpMethod;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
//import org.springframework.security.core.userdetails.User;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.provisioning.InMemoryUserDetailsManager;
//
//@Configuration
//@EnableWebSecurity
////@Order(SecurityProperties.BASIC_AUTH_ORDER - 11)
//
//public class SecurityConfiguration extends WebSecurityConfigurerAdapter{
//	@Autowired
//	private H2ConsoleProperties console;
//	protected void configure(HttpSecurity http) throws Exception {
//		 String path = this.console.getPath();
//         String antPattern = (path.endsWith("/") ? path + "**" : path + "/**");
//         HttpSecurity h2Console = http.antMatcher(antPattern);
//         h2Console.csrf().disable();
//         h2Console.httpBasic();
//         h2Console.headers().frameOptions().sameOrigin();
//
//		http
//			.csrf().disable()
//			.authorizeRequests()
//			.antMatchers(HttpMethod.OPTIONS,"/**").permitAll()
//				.anyRequest().authenticated()
//				.and()
//			//.formLogin().and()
//				
//			.httpBasic();
//		
//        
//	}
//	
//	  @Autowired
//	  public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
//	//	int num= (int)(Math.random()*100);
//		//System.out.println("Password is   .. "+num);
//	    auth
//	      .inMemoryAuthentication()
//	        .withUser("user").password("{noop}"+	"password").roles("USER");
//	  }
//
//}
