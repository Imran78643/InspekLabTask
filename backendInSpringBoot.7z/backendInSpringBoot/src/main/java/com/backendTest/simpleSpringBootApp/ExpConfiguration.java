package com.backendTest.simpleSpringBootApp;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

//import com.backendTest.Beans.HelloBean;
//import com.backendTest.Beans.ipResBean;
 
@Configuration
@Component
public class ExpConfiguration {
//	@Bean
//	@Scope(value="singleton")
//	public ipResBean ipresbean() {
//		System.out.println("Bean created automatically.....");
//		ipResBean ipbean = new ipResBean(new HelloBean("In earlier check"));
//		//ipbean.setUsertype("Admin");
//		System.out.println();
//		return ipbean; 
//	}
	 
	
} 
 