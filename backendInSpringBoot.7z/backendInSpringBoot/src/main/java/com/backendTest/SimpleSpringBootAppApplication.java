package com.backendTest;

import java.util.Arrays;
import java.util.Collections;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@SpringBootApplication
//@ComponentScan(value="com.springBootPractice")
public class SimpleSpringBootAppApplication {

	public static void main(String[] args) {
		 
		ApplicationContext context=SpringApplication.run(SimpleSpringBootAppApplication.class, args);
		System.out.println(context.getDisplayName());
		
		// encoding hardcoded password
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		System.out.println(encoder.encode("inspektLabs"));
				
	}

 
} 
 